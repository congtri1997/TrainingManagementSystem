package edu.hcmuaf.tms;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TrainingManagmentSystemApplicationTests {

	@Test
	public void contextLoads() {
	}

}
