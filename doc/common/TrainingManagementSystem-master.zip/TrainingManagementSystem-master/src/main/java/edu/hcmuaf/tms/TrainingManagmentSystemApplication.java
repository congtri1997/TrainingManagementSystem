package edu.hcmuaf.tms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingManagmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingManagmentSystemApplication.class, args);
	}

}
