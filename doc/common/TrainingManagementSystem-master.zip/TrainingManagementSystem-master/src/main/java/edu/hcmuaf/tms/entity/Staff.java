package edu.hcmuaf.tms.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table
@Entity
public class Staff extends AbstractUser {

}
